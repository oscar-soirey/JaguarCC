const vscode = require('vscode');
const cp = require('child_process');
const path = require('path');
const fs = require('fs');

function encPos(pos) { return { line: pos.line, character: pos.character }; }

function startServer() {
  const cfg = vscode.workspace.getConfiguration('jaguar.languageServer');
  const buildCfg = vscode.workspace.getConfiguration('jaguar.buildSystem');
  const python = cfg.get('python') || 'python';
  const configured = String(cfg.get('path') || '').trim();
  const toolsDirectory = String(buildCfg.get('toolsDirectory') || '').trim();
  const script = configured || (toolsDirectory ? path.join(toolsDirectory, 'jlanguage_server.py') : '');

  if (!script || !fs.existsSync(script)) {
    vscode.window.showErrorMessage(
      'Jaguar: jlanguage_server.py was not found. Configure jaguar.buildSystem.toolsDirectory to the directory containing jcc.py, jbs.py and jlanguage_server.py, or set jaguar.languageServer.path.'
    );
    return undefined;
  }

  return cp.spawn(python, [script], { stdio: ['pipe', 'pipe', 'pipe'] });
}

class JsonRpcClient {
  constructor(proc) {
    this.proc = proc; this.nextId = 1; this.pending = new Map(); this.buffer = Buffer.alloc(0);
    proc.stdout.on('data', d => this.onData(d));
    proc.stderr.on('data', d => console.error('[Jaguar LSP]', d.toString()));
  }
  onData(d) {
    this.buffer = Buffer.concat([this.buffer, d]);
    while (true) {
      const sep = this.buffer.indexOf('\r\n\r\n'); if (sep < 0) return;
      const header = this.buffer.slice(0, sep).toString(); const m = /Content-Length:\s*(\d+)/i.exec(header); if (!m) return;
      const n = Number(m[1]); const start = sep + 4; if (this.buffer.length < start + n) return;
      const body = JSON.parse(this.buffer.slice(start, start+n).toString()); this.buffer = this.buffer.slice(start+n);
      if (body.id && this.pending.has(body.id)) { const p=this.pending.get(body.id); this.pending.delete(body.id); body.error ? p.reject(body.error) : p.resolve(body.result); }
      else if (body.method) this.onNotification?.(body);
    }
  }
  request(method, params) { const id=this.nextId++; this.send({jsonrpc:'2.0',id,method,params}); return new Promise((resolve,reject)=>this.pending.set(id,{resolve,reject})); }
  notify(method, params) { this.send({jsonrpc:'2.0',method,params}); }
  send(o) { const b=Buffer.from(JSON.stringify(o)); this.proc.stdin.write(`Content-Length: ${b.length}\r\n\r\n`); this.proc.stdin.write(b); }
}

function findProjectFile(activeFile) {
  const cfg = vscode.workspace.getConfiguration('jaguar.buildSystem');
  const configured = cfg.get('project');
  if (configured) {
    let configuredPath = configured;
    if (!path.isAbsolute(configuredPath) && vscode.workspace.workspaceFolders?.[0]) {
      configuredPath = path.join(vscode.workspace.workspaceFolders[0].uri.fsPath, configuredPath);
    }
    const uri = vscode.Uri.file(configuredPath);
    if (fs.existsSync(uri.fsPath) && uri.fsPath.toLowerCase().endsWith('.jbs')) return uri.fsPath;
    if (fs.existsSync(uri.fsPath)) vscode.window.showWarningMessage(`Jaguar: the configured project is not a .jbs file: ${uri.fsPath}`);
  }

  const currentDir = activeFile
    ? path.dirname(activeFile)
    : vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;

  if (!currentDir) {
    vscode.window.showErrorMessage('Jaguar: unable to determine the current directory. Open a Jaguar project file.');
    return undefined;
  }

  if (activeFile && activeFile.toLowerCase().endsWith('.jbs') && fs.existsSync(activeFile)) {
    return activeFile;
  }

  let candidates = [];
  try {
    candidates = fs.readdirSync(currentDir)
      .filter(n => n.toLowerCase().endsWith('.jbs'))
      .map(n => path.join(currentDir, n));
  } catch (e) {
    vscode.window.showErrorMessage(`Jaguar: unable to read the current directory: ${currentDir}`);
    return undefined;
  }

  return candidates;
}

async function chooseProject(activeFile) {
  const found = findProjectFile(activeFile);
  if (typeof found === 'string') return found;
  const projects = found || [];
  if (projects.length === 0) {
    const dir = activeFile ? path.dirname(activeFile) : (vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '');
    vscode.window.showErrorMessage(`Jaguar: no .jbs file found in the current directory: ${dir}`);
    return undefined;
  }
  if (projects.length === 1) return projects[0];
  const picked = await vscode.window.showQuickPick(
    projects.map(p => ({ label: path.basename(p), description: path.dirname(p), path: p })),
    { placeHolder: 'Choose the Jaguar project to build' }
  );
  return picked?.path;
}

async function compileProject(context, runAfterBuild = false) {
  const editor = vscode.window.activeTextEditor;
  const project = await chooseProject(editor?.document.uri.fsPath);
  if (!project) return;

  const cfg = vscode.workspace.getConfiguration('jaguar.buildSystem');
  const python = cfg.get('python') || 'python';
  const toolsDirectory = String(cfg.get('toolsDirectory') || '').trim();

  if (!toolsDirectory) {
    vscode.window.showErrorMessage(
      "Jaguar: the tools directory is not configured. Set jaguar.buildSystem.toolsDirectory to the directory containing jbs.py and jcc.py."
    );
    return;
  }

  const jbs = path.join(toolsDirectory, 'jbs.py');
  const jcc = path.join(toolsDirectory, 'jcc.py');
  if (!fs.existsSync(jbs)) {
    vscode.window.showErrorMessage(`Jaguar: jbs.py was not found in the configured directory: ${toolsDirectory}`);
    return;
  }
  if (!fs.existsSync(jcc)) {
    vscode.window.showErrorMessage(`Jaguar: jcc.py was not found in the configured directory: ${toolsDirectory}`);
    return;
  }

  // JBS gère lui-même JCC et tous les autres paramètres. L'extension ne lui
  // add no options: it only runs `python jbs.py project.jbs`.
  const terminal = vscode.window.createTerminal({
    name: runAfterBuild ? 'Jaguar Build & Run' : 'Jaguar Build',
    cwd: path.dirname(project)
  });
  terminal.show(true);
  terminal.sendText(`${quoteExecutable(python)} ${quoteArg(jbs)} ${quoteArg(project)}`);
}

function quoteArg(s) {
  if (process.platform === 'win32') return `"${String(s).replace(/"/g, '\\"')}"`;
  return `'${String(s).replace(/'/g, "'\\''")}'`;
}

function quoteExecutable(s) {
  const value = String(s);
  if (process.platform !== 'win32') return quoteArg(value);
  if (/^[A-Za-z0-9_.-]+$/.test(value)) return value;
  return `& ${quoteArg(value)}`;
}

function provideJbsCompletion(doc, position) {
  const line = doc.lineAt(position.line).text;
  const before = line.slice(0, position.character);
  const text = doc.getText();
  const items = [];
  // Completion inside a compile block: suggest Jaguar source files from the project directory.
  const openBlocks = (text.match(/\{/g) || []).length;
  const closeBlocks = (text.match(/\}/g) || []).length;
  const inBlock = openBlocks > closeBlocks;
  const wantsFile = inBlock && /(?:^|\s)[^{}\n]*$/.test(before) && !/\b(?:compile|version|out|include|define)\s*$/.test(before);
  if (wantsFile) {
    const dir = path.dirname(doc.uri.fsPath);
    const seen = new Set();
    const addFiles = (folder) => {
      try {
        for (const name of fs.readdirSync(folder)) {
          if (!/\.(?:ja|jah)$/i.test(name)) continue;
          const full = path.join(folder, name);
          if (seen.has(full)) continue;
          seen.add(full);
          const i = new vscode.CompletionItem(name, vscode.CompletionItemKind.File);
          i.detail = 'Jaguar file';
          items.push(i);
        }
      } catch (_) {}
    };
    addFiles(dir);
  }

  const trimmed = before.trim();
  const generic = [
    ['version', vscode.CompletionItemKind.Keyword, 'JBS format version'],
    ['out', vscode.CompletionItemKind.Keyword, 'Output directory'],
    ['include', vscode.CompletionItemKind.Keyword, 'Search directory for using'],
    ['define', vscode.CompletionItemKind.Keyword, 'C macro definition'],
    ['c89', vscode.CompletionItemKind.Keyword, 'Request C89 output'],
    ['keep_c', vscode.CompletionItemKind.Keyword, 'Keep the generated C file'],
    ['compile', vscode.CompletionItemKind.Keyword, 'Declares a build target']
  ];
  for (const [label, kind, detail] of generic) {
    const i = new vscode.CompletionItem(label, kind);
    i.detail = detail;
    items.push(i);
  }

  if (/^version\s*$/.test(trimmed)) {
    const i = new vscode.CompletionItem('1.0', vscode.CompletionItemKind.Value);
    i.detail = 'Supported JBS version';
    items.push(i);
  }

  if (/^compile\s*$/.test(trimmed)) {
    const i = new vscode.CompletionItem('game', vscode.CompletionItemKind.Class);
    i.detail = 'Target name';
    i.insertText = 'game';
    items.push(i);
  }

  return items;
}

function activate(context) {
  const proc = startServer();
  if (!proc) return;
  const client = new JsonRpcClient(proc);
  const diagCollection = vscode.languages.createDiagnosticCollection('jaguar');
  client.onNotification = msg => {
    if (msg.method === 'textDocument/publishDiagnostics') {
      const uri = vscode.Uri.parse(msg.params.uri); const ds = msg.params.diagnostics || [];
      const mapped = ds.map(d => new vscode.Diagnostic(
        new vscode.Range(d.range.start.line,d.range.start.character,d.range.end.line,d.range.end.character), d.message,
        d.severity === 1 ? vscode.DiagnosticSeverity.Error : vscode.DiagnosticSeverity.Warning));
      diagCollection.set(uri,mapped);
    }
  };
  context.subscriptions.push(diagCollection);
  context.subscriptions.push(vscode.commands.registerCommand('jaguar.compileProject', () => compileProject(context, false)));
  context.subscriptions.push(vscode.commands.registerCommand('jaguar.buildAndRun', () => compileProject(context, true)));

  client.request('initialize', { processId: process.pid, rootUri: vscode.workspace.workspaceFolders?.[0]?.uri.toString() || null, capabilities: { textDocument: { completion: { completionItem: { snippetSupport: false } } } } }).then(() => client.notify('initialized', {}));
  const selector = [{ language: 'jaguar', scheme: 'file' }, { language: 'jaguar-header', scheme: 'file' }];
  const jbsSelector = [{ language: 'jbs', scheme: 'file' }];
  const disposables = [];
  disposables.push(vscode.workspace.onDidOpenTextDocument(doc => open(doc)));
  disposables.push(vscode.workspace.onDidChangeTextDocument(e => change(e.document)));
  disposables.push(vscode.workspace.onDidCloseTextDocument(doc => client.notify('textDocument/didClose',{textDocument:{uri:doc.uri.toString()}})));
  function open(doc) { if (doc.languageId !== 'jaguar' && doc.languageId !== 'jaguar-header') return; client.notify('textDocument/didOpen',{textDocument:{uri:doc.uri.toString(),languageId:'jaguar',version:doc.version,text:doc.getText()}}); }
  function change(doc) { if (doc.languageId !== 'jaguar' && doc.languageId !== 'jaguar-header') return; client.notify('textDocument/didChange',{textDocument:{uri:doc.uri.toString(),version:doc.version},contentChanges:[{text:doc.getText()}]}); }
  vscode.workspace.textDocuments.forEach(open);

  const completion = vscode.languages.registerCompletionItemProvider(selector, {
    provideCompletionItems: async (doc, position) => {
      try {
        const r = await client.request('textDocument/completion',{textDocument:{uri:doc.uri.toString()},position:encPos(position)});
        const items = r?.items || [];
        return items.map(x => { const i=new vscode.CompletionItem(x.label, x.kind || vscode.CompletionItemKind.Text); i.detail=x.detail; i.documentation=x.documentation; i.insertText=x.insertText || x.label; return i; });
      } catch(e) { return []; }
    }
  }, '.', ':', '<');

  const jbsCompletion = vscode.languages.registerCompletionItemProvider(jbsSelector, {
    provideCompletionItems: async (doc, position) => provideJbsCompletion(doc, position)
  }, ' ', '\n', '{', '.');
  const hover = vscode.languages.registerHoverProvider(selector, { provideHover: async (doc,pos) => {
    try { const r=await client.request('textDocument/hover',{textDocument:{uri:doc.uri.toString()},position:encPos(pos)}); if(!r) return; return new vscode.Hover(new vscode.MarkdownString(r.contents?.value || '')); } catch(e) {}
  }});
  const definition = vscode.languages.registerDefinitionProvider(selector, { provideDefinition: async (doc,pos) => {
    try { const r=await client.request('textDocument/definition',{textDocument:{uri:doc.uri.toString()},position:encPos(pos)}); return (r||[]).map(x=>new vscode.Location(vscode.Uri.parse(x.uri),new vscode.Range(x.range.start.line,x.range.start.character,x.range.end.line,x.range.end.character))); } catch(e) { return []; }
  }});
  context.subscriptions.push(...disposables,completion,jbsCompletion,hover,definition,{dispose:()=>{client.notify('shutdown',{}); proc.kill();}});
}
function deactivate() {}
module.exports={activate,deactivate};
